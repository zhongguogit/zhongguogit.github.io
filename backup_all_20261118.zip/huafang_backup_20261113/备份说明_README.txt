==== 掌上画坊 备份包说明 2026-11-13 ====
本包 = 纸层 + 图纸层 全套异机备份(沙箱生成)
内容:
  SD15_golden_firmware_v1.sh     一键固件原件(14541字节)
  AI交接记忆_SD15手机出图_GOLDENv1.txt  AI门票(含v2工作流补记)
  SD15_golden_RECORD.txt         花屏大案全案记录
  SD15_golden_MISSION.txt        使命备忘
  sd15_golden_backup.sh          急救包重建脚本
  文件来源清单.txt               九项资产指纹清单
  此文件夹最重要.txt             核心孤本说明
  客户使用说明.txt               客户三步安装
  路线图.txt                     开发部路线图v2(四大使命)
  协作章程.txt                   协作章程v1
  图生图工作流.json              M2图纸(denoise0.55版)
  参赛三件套.txt                 TRAE大赛报名材料
  workflows_history/             全部历史工作流JSON(00047基准~00058)
本包不含: 模型孤本(sd15_Q4_0.gguf 1.47G / sd15_clip_l.safetensors 246M)
  → 模型层只在手机存储与U盘, 用文件管理器拷贝三版本包+开发部两个文件夹
恢复方法: 新环境装固件 + 按清单核对指纹 + 门票贴给AI即复装完成
===END===
