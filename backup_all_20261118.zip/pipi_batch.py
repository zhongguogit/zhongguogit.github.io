#!/usr/bin/env python
# 换皮管线 v1 —— 逐帧图生图批量机（黄金v2参数冻结）
# 用法: ~/comfyui/venv/bin/python ~/vidwork/pipi_batch.py
# 前提: ComfyUI 已启动 (start_golden.sh)
import os, json, time, glob, uuid, urllib.request

SRC = os.path.expanduser("~/vidwork/src")
BASE = "http://127.0.0.1:8188"
PREFIX = "pip"

POS = "a young chinese woman in ancient costume, cinematic lighting, film still, highly detailed"
NEG = "ugly, deformed, blurry, noisy, pixelated, mutated"

def api(path, data=None, files=None):
    url = BASE + path
    if files:
        boundary = uuid.uuid4().hex
        body = b""
        for k, v in files.items():
            fname, fdata = v
            disp = 'Content-Disposition: form-data; name="%s"' % k
            if fname:
                disp += '; filename="%s"' % fname
            body += (disp + "\r\n" + "Content-Type: application/octet-stream\r\n\r\n").encode()
            body += fdata + b"\r\n"
        body += ("--%s--\r\n" % boundary).encode()
        req = urllib.request.Request(url, data=body,
            headers={"Content-Type": "multipart/form-data; boundary=" + boundary})
    elif data is not None:
        req = urllib.request.Request(url, data=json.dumps(data).encode(),
            headers={"Content-Type": "application/json"})
    else:
        req = urllib.request.Request(url)
    return urllib.request.urlopen(req, timeout=600).read()

def workflow(frame):
    return {
      "31": {"class_type": "UNETLoader", "inputs": {
        "unet_name": "sd15_dequant_fp16.safetensors", "weight_dtype": "fp8_e4m3fn"}},
      "2": {"class_type": "CLIPLoader", "inputs": {
        "clip_name": "sd15_clip_l.safetensors", "type": "stable_diffusion", "device": "cpu"}},
      "3": {"class_type": "CLIPTextEncode", "inputs": {"clip": ["2", 0], "text": POS}},
      "4": {"class_type": "CLIPTextEncode", "inputs": {"clip": ["2", 0], "text": NEG}},
      "27": {"class_type": "VAELoader", "inputs": {
        "vae_name": "vae-ft-mse-840000-ema-pruned.safetensors"}},
      "40": {"class_type": "LoadImage", "inputs": {"image": frame}},
      "41": {"class_type": "VAEEncode", "inputs": {"pixels": ["40", 0], "vae": ["27", 0]}},
      "6": {"class_type": "KSampler", "inputs": {
        "model": ["31", 0], "positive": ["3", 0], "negative": ["4", 0],
        "latent_image": ["41", 0], "seed": 123460, "steps": 24, "cfg": 7,
        "sampler_name": "euler_ancestral", "scheduler": "karras", "denoise": 0.55}},
      "17": {"class_type": "VAEDecodeTiled", "inputs": {
        "samples": ["6", 0], "vae": ["27", 0],
        "tile_size": 320, "overlap": 32, "temporal_size": 64, "temporal_overlap": 8}},
      "9": {"class_type": "SaveImage", "inputs": {"images": ["17", 0], "filename_prefix": PREFIX}}
    }

# 开工前体检: 服务器活着吗
try:
    api("/system_stats")
except Exception as e:
    raise SystemExit("ComfyUI 没醒! 先跑 ~/golden_cfg/start_golden.sh 等满60秒再来")

frames = sorted(glob.glob(SRC + "/f*.jpg"))
print("共 %d 帧, 黄金v2: euler_ancestral/karras/24步/cfg7/denoise0.55/seed123460" % len(frames))
ok, fail = 0, 0
t0 = time.time()
for i, f in enumerate(frames, 1):
    name = os.path.basename(f)
    try:
        data = open(f, "rb").read()
        api("/upload/image", files={"image": (name, data), "overwrite": (None, b"1")})
        r = json.loads(api("/prompt", {"prompt": workflow(name)}))
        pid = r["prompt_id"]
        while True:
            h = json.loads(api("/history/" + pid))
            if pid in h and h[pid].get("outputs"):
                ok += 1
                break
            time.sleep(10)
        dt = (time.time() - t0) / i
        print("[%d/%d] %s 完成, 均速%.1f分/帧, 预计还剩%.0f分钟" %
              (i, len(frames), name, dt / 60.0, (len(frames) - i) * dt / 60.0))
    except Exception as e:
        fail += 1
        print("[%d/%d] %s 失败: %s" % (i, len(frames), name, e))
print("收工: 成%d 败%d, 成品在 ~/comfyui/ComfyUI/output/pip_*.png" % (ok, fail))
