#!/usr/bin/env python3
"""
分段助手

按三种策略切分长文档，输出可直接喂给模型的分段文件 + 一份 manifest。

用法：
    python chunk.py --in report.md --mode auto --window 32000 --out ./segs
    python chunk.py --in book.txt --mode heading --out ./segs
    python chunk.py --in report.md --mode fixed --size 10000 --overlap 800 --out ./segs

输出：
    segs/seg_001.txt ...
    segs/manifest.json   （每段的字符数、起止位置、预估 token）
"""
import argparse
import json
import os
import re
import sys


def est_tokens(text):
    """中文按 1 字 ≈ 1.6 token，英文按 1 词 ≈ 1.3 token，取混合估算"""
    cjk = len(re.findall(r"[\u4e00-\u9fff]", text))
    words = len(re.findall(r"[A-Za-z]+", text))
    other = max(0, len(text) - cjk - words)
    return int(cjk * 1.6 + words * 1.3 + other * 0.3)


def split_fixed(text, size, overlap):
    segs = []
    i = 0
    n = len(text)
    step = max(1, size - overlap)
    while i < n:
        segs.append((i, min(i + size, n)))
        if i + size >= n:
            break
        i += step
    return segs


def split_heading(text):
    """按 markdown 标题或中文数字章节切"""
    pattern = re.compile(r"(?m)^(#{1,3}\s+.+|第[一二三四五六七八九十百]+[章节部分].*)$")
    marks = [m.start() for m in pattern.finditer(text)]
    if len(marks) < 2:
        return None
    marks.append(len(text))
    segs = []
    for i in range(len(marks) - 1):
        segs.append((marks[i], marks[i + 1]))
    return segs


def main():
    ap = argparse.ArgumentParser(description="长文档分段（输出 JSON manifest，便于追溯）")
    ap.add_argument("--in", dest="inp", required=True, help="输入文件（.md/.txt）")
    ap.add_argument("--out", required=True, help="输出目录")
    ap.add_argument("--mode", choices=["auto", "fixed", "heading"], default="auto")
    ap.add_argument("--window", type=int, default=32000, help="模型上下文窗口（token）")
    ap.add_argument("--size", type=int, default=0, help="固定模式下每段字符数")
    ap.add_argument("--overlap", type=int, default=800, help="重叠字符数")
    a = ap.parse_args()

    with open(a.inp, encoding="utf-8", errors="replace") as f:
        text = f.read()

    total_tok = est_tokens(text)
    limit = int(a.window * 0.60)  # 留 40% 给输出与指令

    print(f"文档：{len(text)} 字符，约 {total_tok} token")
    print(f"窗口：{a.window} token，单段上限约 {limit} token")

    mode = a.mode
    if mode == "auto":
        if total_tok <= limit:
            print("→ 一次可读完，无需分段（仍会切 1 段输出，方便统一流程）")
            mode = "fixed"
        else:
            h = split_heading(text)
            mode = "heading" if h else "fixed"
            print(f"→ 自动选择：{mode}")

    if mode == "heading":
        segs = split_heading(text)
        if not segs:
            print("未找到章节标题，回退到固定切分")
            mode = "fixed"

    if mode == "fixed":
        size = a.size or max(2000, int(limit / 1.6))
        print(f"→ 固定切分：每段 {size} 字符，重叠 {a.overlap}")
        segs = split_fixed(text, size, a.overlap)
    else:
        print(f"→ 按章节切分：{len(split_heading(text))} 段")

    os.makedirs(a.out, exist_ok=True)
    manifest = []
    for i, (s, e) in enumerate(segs, 1):
        piece = text[s:e]
        name = f"seg_{i:03d}.txt"
        with open(os.path.join(a.out, name), "w", encoding="utf-8") as f:
            f.write(piece)
        manifest.append({
            "index": i,
            "file": name,
            "start": s,
            "end": e,
            "chars": len(piece),
            "est_tokens": est_tokens(piece),
        })
        flag = " ⚠ 超限" if est_tokens(piece) > limit else ""
        print(f"  {name}  {len(piece)} 字符  ~{est_tokens(piece)} token{flag}")

    with open(os.path.join(a.out, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump({
            "source": a.inp,
            "total_chars": len(text),
            "est_tokens": total_tok,
            "mode": mode,
            "segments": manifest,
        }, f, ensure_ascii=False, indent=2)

    over = [m for m in manifest if m["est_tokens"] > limit]
    if over:
        print(f"\n⚠ 有 {len(over)} 段超过单段上限，建议减小 size 或换更大窗口的模型")
        return 1
    print(f"\n完成。manifest 在 {os.path.join(a.out, 'manifest.json')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
