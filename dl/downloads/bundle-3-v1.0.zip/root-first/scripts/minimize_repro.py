#!/usr/bin/env python3
"""
最小化复现助手

思路：不是让程序自动删代码（那太危险），而是把「删除 - 测试 - 保留/回滚」
这个循环做成一个可重复的流程，你只需要提供一条「判断是否复现」的命令。

用法：
    python minimize_repro.py --repo ./myproject --test "python test_bug.py"
    python minimize_repro.py --repo ./src --test "npm test -- --grep 出错的那个" --dry-run

它会：
    1. 递归收集候选文件（排除 .git / node_modules / 测试外的东西）
    2. 逐个尝试删除，删完跑一次 test 命令
    3. 如果问题「消失了」（命令返回 0），说明这个文件是必要的 → 恢复
    4. 如果问题「还在」（命令返回非 0），说明这个文件无关 → 永久删除副本

注意：全程在临时副本里操作，不动原仓库。
"""
import argparse
import os
import shutil
import subprocess
import sys
import tempfile

SKIP_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv",
             "dist", "build", ".next", "target", ".idea", "venv2", ".cache"}
SKIP_EXT = {".pyc", ".pyo", ".log", ".lock", ".save"}


def collect(root):
    out = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for f in filenames:
            if os.path.splitext(f)[1].lower() in SKIP_EXT:
                continue
            out.append(os.path.join(dirpath, f))
    return out


def run_test(cmd, cwd):
    """返回 True 表示「问题消失了」（测试通过）"""
    try:
        r = subprocess.run(cmd, shell=True, cwd=cwd, timeout=180,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return r.returncode == 0
    except subprocess.TimeoutExpired:
        return False


def main():
    ap = argparse.ArgumentParser(description="最小化复现范围（在临时副本里操作，不动原目录）")
    ap.add_argument("--repo", required=True, help="要最小化的目录")
    ap.add_argument("--test", required=True, help="判断问题是否复现的命令（返回 0 = 问题消失）")
    ap.add_argument("--dry-run", action="store_true", help="只列出候选文件，不实际删")
    ap.add_argument("--max-rounds", type=int, default=200, help="最多尝试多少轮")
    a = ap.parse_args()

    src = os.path.abspath(a.repo)
    if not os.path.isdir(src):
        print(f"目录不存在：{src}")
        return 2

    work = tempfile.mkdtemp(prefix="minrepro_")
    dst = os.path.join(work, os.path.basename(src))
    shutil.copytree(src, dst, ignore=shutil.ignore_patterns(*SKIP_DIRS))
    print(f"临时副本：{dst}")

    files = collect(dst)
    print(f"候选文件：{len(files)} 个")
    if a.dry_run:
        for f in files[:50]:
            print("  ", os.path.relpath(f, dst))
        if len(files) > 50:
            print(f"  ... 还有 {len(files)-50} 个")
        shutil.rmtree(work, ignore_errors=True)
        return 0

    # 基线：现在应该「问题存在」= 测试失败
    if run_test(a.test, dst):
        print("警告：在当前状态下测试是通过的，说明问题没复现。先修好复现步骤再来。")
        shutil.rmtree(work, ignore_errors=True)
        return 2

    removed = []
    for i, f in enumerate(files[: a.max_rounds], 1):
        rel = os.path.relpath(f, dst)
        backup = f + ".bak_min"
        try:
            os.rename(f, backup)
        except OSError:
            continue

        if run_test(a.test, dst):
            # 问题消失了 → 这个文件必要 → 恢复
            os.rename(backup, f)
            status = "保留（必要）"
        else:
            # 问题还在 → 无关 → 删掉备份
            os.remove(backup)
            removed.append(rel)
            status = "删除（无关）"

        print(f"[{i}/{min(len(files), a.max_rounds)}] {rel} → {status}")

    print()
    print(f"已排除 {len(removed)} 个无关文件。")
    print(f"剩下的代码在：{dst}")
    print("把它和原始版本的 diff 看一遍，根因通常就在里面。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
