#!/usr/bin/env python3
"""
skill-smith 自动校验器
检查 12 项里的前 8 项，后 4 项需要人看。

用法：
    python validate.py <技能目录>
    python validate.py ~/.claude/skills/my-skill
"""
import os
import re
import sys

ALLOWED_KEYS = {"name", "description", "license", "allowed-tools", "metadata", "compatibility"}

# 凭据特征。注意：只是特征串，不校验真实有效性
CRED_PATTERNS = [
    ("OpenAI key", re.compile(r"\bsk-[A-Za-z0-9]{20,}")),
    ("GitHub token", re.compile(r"\bghp_[A-Za-z0-9]{20,}")),
    ("AWS key", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("私钥块", re.compile(r"BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY")),
    ("Google key", re.compile(r"\bAIza[0-9A-Za-z_\-]{30,}")),
]

# 出现这些词说明是在「禁止」而不是「在用」
NEGATION = ("禁止", "不要", "不得", "避免", "禁用", "严禁", "不许", "❌", "反面",
            "反模式", "错误写法", "avoid", "never", "don't", "forbidden")


class R:
    def __init__(self):
        self.ok = 0
        self.warn = 0
        self.err = 0
        self.items = []

    def add(self, level, name, msg):
        self.items.append((level, name, msg))
        if level == "ERR":
            self.err += 1
        elif level == "WARN":
            self.warn += 1
        else:
            self.ok += 1

    def report(self):
        icon = {"OK": "  ok  ", "WARN": " warn ", "ERR": " FAIL "}
        for lv, name, msg in self.items:
            print(f"[{icon[lv]}] {name}: {msg}")
        print()
        print(f"通过 {self.ok} · 警告 {self.warn} · 失败 {self.err}")
        return self.err == 0


def parse_frontmatter(text):
    """极简 YAML 解析：只处理 key: value 和块标量 | >"""
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return None, text
    end = None
    for i in range(1, len(lines)):
        if lines[i].strip() == "---":
            end = i
            break
    if end is None:
        return None, text

    data = {}
    i = 1
    body_start = end + 1
    while i < end:
        line = lines[i]
        if not line.strip() or line.lstrip().startswith("#"):
            i += 1
            continue
        if ":" not in line:
            i += 1
            continue
        key, val = line.split(":", 1)
        key = key.strip()
        val = val.strip()

        # 块标量 | 或 >
        if re.fullmatch(r"[|>][+-]?", val):
            block = []
            i += 1
            while i < end and (lines[i].startswith((" ", "\t")) or not lines[i].strip()):
                block.append(lines[i].strip())
                i += 1
            sep = "\n" if val.startswith("|") else " "
            data[key] = sep.join(x for x in block if x)
            continue

        # 去掉引号
        if len(val) >= 2 and val[0] == val[-1] and val[0] in "\"'":
            val = val[1:-1]
        data[key] = val
        i += 1

    return data, "\n".join(lines[body_start: end:] + lines[end + 1:])


def strip_code_blocks(text):
    return re.sub(r"```[\s\S]*?```", "", text)


def check(skill_dir):
    r = R()
    d = os.path.abspath(skill_dir).rstrip(os.sep)
    if not os.path.isdir(d):
        print(f"目录不存在：{d}")
        return False

    md = os.path.join(d, "SKILL.md")
    if not os.path.isfile(md):
        print(f"找不到 {md}")
        return False

    with open(md, encoding="utf-8") as f:
        text = f.read()

    fm, body = parse_frontmatter(text)
    if fm is None:
        r.add("ERR", "1-frontmatter", "SKILL.md 开头缺 --- 包裹的 frontmatter")
        r.report()
        return False

    # 1 键白名单
    bad = set(fm) - ALLOWED_KEYS
    if bad:
        r.add("ERR", "1-键名", f"出现非法键 {sorted(bad)}，只允许 {sorted(ALLOWED_KEYS)}")
    else:
        r.add("OK", "1-键名", f"{len(fm)} 个键全部合法")

    # 2 name 格式
    name = fm.get("name", "")
    if not re.fullmatch(r"[a-z0-9-]+", name or ""):
        r.add("ERR", "2-name格式", f"'{name}' 不合法，只能小写字母/数字/连字符")
    else:
        r.add("OK", "2-name格式", name)

    # 3 name 与目录一致
    base = os.path.basename(d)
    if name and name != base:
        r.add("ERR", "3-name一致", f"name='{name}' 但目录名='{base}'，加载会失败")
    else:
        r.add("OK", "3-name一致", name)

    # 4 description 长度
    desc = fm.get("description", "")
    n = len(desc)
    if n == 0:
        r.add("ERR", "4-description", "为空")
    elif n > 1024:
        r.add("ERR", "4-description", f"{n} 字符，超过 1024 上限")
    elif n > 300:
        r.add("WARN", "4-description", f"{n} 字符，建议压到 300 以内")
    else:
        r.add("OK", "4-description", f"{n} 字符")

    # 5 触发词
    triggers = ["当用户", "当出现", "使用于", "用于", "when", "use when", "trigger"]
    if not any(t.lower() in desc.lower() for t in triggers):
        r.add("WARN", "5-触发词", "description 里没有「当用户说…」这类触发语，很可能不触发")
    else:
        r.add("OK", "5-触发词", "含触发语")

    # 6 正文行数
    lines = [x for x in body.splitlines() if x.strip()]
    if len(lines) > 500:
        r.add("WARN", "6-正文长度", f"{len(lines)} 行，建议拆到 references/")
    else:
        r.add("OK", "6-正文长度", f"{len(lines)} 行")

    # 7 硬编码凭据（只看代码块和引号内，跳过「禁止」上下文）
    hits = []
    for m in re.finditer(r"```[\s\S]*?```|`[^`\n]+`|\"[^\"]{8,}\"|'[^']{8,}'", text):
        seg = m.group(0)
        line_start = text.rfind("\n", 0, m.start()) + 1
        ctx = text[max(0, line_start - 60): line_start + len(seg)]
        if any(w.lower() in ctx.lower() for w in NEGATION):
            continue
        for label, pat in CRED_PATTERNS:
            if pat.search(seg):
                hits.append(label)
    if hits:
        r.add("ERR", "7-凭据", f"疑似硬编码 {set(hits)}，改从环境变量读")
    else:
        r.add("OK", "7-凭据", "未发现硬编码凭据")

    # 8 引用文件存在（只认行内代码 `path` 和 markdown 链接，避免把示例路径当引用）
    refs = set()
    for m in re.finditer(r"`((?:references|scripts|template|assets)/[\w\-./]+\.\w+)`", text):
        refs.add(m.group(1))
    for m in re.finditer(r"\]\(((?:references|scripts|template|assets)/[\w\-./]+\.\w+)\)", text):
        refs.add(m.group(1))
    missing = []
    for p in sorted(refs):
        if not os.path.exists(os.path.join(d, p)):
            missing.append(p)
    if missing:
        r.add("ERR", "8-引用", f"文件不存在：{sorted(set(missing))}")
    else:
        r.add("OK", "8-引用", "引用的文件都在")

    # 9-12 提示人工确认
    for k, tip in [
        ("9-失败实测", "回看：有没有真的看过 Agent 失败？没有的话这个技能可能是空的"),
        ("10-失败输出", "确认：正文里写了「失败时输出什么」吗？没写会幻觉成功"),
        ("11-可判定", "确认：每条规则都能举出反例吗？举不出的删掉"),
        ("12-降级", "确认：主路径失败时有降级路径吗？"),
    ]:
        r.add("WARN", k, tip)

    return r.report()


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(2)
    ok = check(sys.argv[1])
    sys.exit(0 if ok else 1)
