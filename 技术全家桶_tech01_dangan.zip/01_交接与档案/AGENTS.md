# AGENTS.md
本工作区的进行中项目: **SD1.5 安卓手机(Termux)出图** —— 长期任务, 当前 GOLDEN v1 (2026-11-10)。

新会话必读(按序):
1. `/workspace/AI_HANDOFF.md` —— 交接总纲(用户沟通方式/环境铁律/当前状态/开场要做)
2. `/workspace/SD15_golden_RECORD.txt` —— 全案记录(细化版, 每个实验的判决)
3. `/workspace/SD15_golden_MISSION.txt` —— 长期任务章程(版本制度/实验守则/技术换代条款)

红线:
- 不得破坏黄金配置(GOLDEN v1): 黄金四件模型文件与工作流参数冻结, 不改名/不覆盖/不删除
- 实验一律 test_ 前缀副本 + 一次一个变量
- 严禁把 GGUF 文件接入 UnetLoaderGGUF 节点(真凶已定罪, 见 RECORD.txt)
- 出现更先进技术时按 MISSION.txt 流程立即评估换代
- 本沙箱不是用户手机: 手机操作一律给"可整段粘贴的 Termux 命令块", 由用户执行后回传截图
