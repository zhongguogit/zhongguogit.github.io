# AI 交接档案 · SD1.5 手机出图项目
<!-- 新对话的 AI: 读完本文件即完成交接, 然后执行[五、开场要做] -->

## 一、这个项目是什么
在用户的安卓手机(HarmonyOS 4.0)的 Termux 里, 用 ComfyUI(纯 CPU) 跑 SD1.5 文生图。
经历长期"花屏(高饱和彩色噪点)"排障, 于 2026-11-10 破案并跑通, 立卡 **GOLDEN v1**。
- 完整案情与每个实验细节: 读 `/workspace/SD15_golden_RECORD.txt`
- 长期任务章程(版本制度/实验守则/技术换代条款): 读 `/workspace/SD15_golden_MISSION.txt`

## 二、必须知道的沟通方式(认识用户)
1. 全程简体中文。用户不是程序员, 命令必须**整段可复制粘贴**, 一个代码块搞定
2. 用户习惯发截图代替打字 —— 要会读截图里的终端输出/报错/工作流界面
3. 用户语言是直觉比喻("三件套/花屏/碎渣/黄土布"), 回应也要直观, 不堆术语
4. 方法论: 判决性实验 + 逐级排除 + 一次只改一个变量, 每个实验给明确"判决"
5. 回复要短、直接、先结论后命令, 不绕弯
6. 用户立的总规矩(永久有效):
   - ① 绝不能把"现在能出图的文件/配置"搞乱 —— 黄金配置冻结, 实验一律 test_ 副本
   - ② 出现更先进的技术时, 立即评估并换代成新黄金配置(流程见 MISSION.txt)

## 三、环境铁律
- **本沙箱(/workspace)不是用户的手机!** 沙箱里无法直接操作手机
- 一切手机操作 = 我给命令块 → 用户整段粘贴进 Termux → 用户回传截图/输出
- 用户上传的文件在 `/workspace/.uploads`(只读)
- 交付物放 `/workspace`, 用 computer:// 链接给用户

## 四、当前技术状态(GOLDEN v1 速览)
- 手机: 5.5Gi 内存(可用约 1.7Gi), Termux + python venv + ComfyUI 纯 CPU
- 黄金四件:
  - `models/unet/sd15_Q4_0.gguf` (1,566,768,416 字节, sha256 b8944e9f...2261f 官方一致)
  - `models/unet/sd15_dequant_fp16.safetensors` (~1.7G, 离线反量化产物, 859.5M 参数)
  - `models/clip/sd15_clip_l.safetensors` (246,144,864 字节)
  - `models/vae/vae-ft-mse-840000-ema-pruned.safetensors` (334,641,190 字节)
- **命门**: UNETLoader 的 weight_dtype = `fp8_e4m3fn`
  (fp16 整块直载需 2.4G > 可用 1.7G, 会被安卓低内存杀手秒杀: 浏览器报 Failed to fetch)
- 已定罪真凶: ComfyUI-GGUF 插件"边跑边反量化"运行时 × Termux torch 数值出错
  → **严禁再用 UnetLoaderGGUF 节点**(除非 MISSION.txt 观察清单第 1 项的修复落地)
- 黄金工作流基准: `ComfyUI_00047_.json`(384x384, cfg7, steps20, dpmpp_2m+karras)
- 手机端备份: `~/golden_cfg/`(第一套) + `/sdcard/comfyui_golden_backup/`(第二套)

## 五、开场要做
1. 向用户确认: 备份固件是否已在手机跑完(~/golden_cfg/ 应有 8 个文件)
2. 索要 `ComfyUI_00047_.png` 的画质判定(人像还是碎渣?) —— 全案唯一悬案
3. 按 MISSION.txt 的[当前待办]推进: 画质 OK → 提质量路线; 不 OK → 再排障

## 六、给用户的新对话开场白(复制这句即可)
> 读 /workspace/AI_HANDOFF.md、/workspace/SD15_golden_RECORD.txt、
> /workspace/SD15_golden_MISSION.txt 三份档案完成交接。
> 当前 GOLDEN v1。汇报 00047 画质判定结果, 然后告诉我下一步。

## 七、2026-11-13 ~ 11-18 大事记(最新状态, 新会话先读这节)

### A. 平行中国游戏 · 已上线 ✅
- 部署: GitHub Pages, 游戏在**独立仓库** `zhongguogit/pingxing-zhongguo`(主仓库 zhongguogit.github.io 下无此目录)
- 线上地址: https://zhongguogit.github.io/pingxing-zhongguo/
- 部署方式: 沙箱内 git push(令牌用过即删, 建议用户去 GitHub Settings 删残留)
- 待用户手动: GitHub 主页 Customize your pins 把游戏置顶
- 手机 Termux 克隆是可选流程(其 pkg 清华源 termux-packages-24 报 403, 需换 HUST 源或升级 Termux App)

### B. 换皮视频管线 · v1.2 全自动 ⏳(跑批中)
- 目标: 43 帧 BBB 源帧(448x256, ~/vidwork/src/f*.jpg)逐帧 SD1.5 换皮 → ffmpeg 拼片
- 工作流参数: seed=123460, steps=24, cfg=7, euler_ancestral+karras, denoise=0.55, fp8_e4m3fn 载入
- **11-19 花屏排障**: 会诊窗口定罪 VAEDecodeTiled 分块解码 bug(448x256 无需分块) → 已改普通
  VAEDecode(tile 参数已删); 旧 png 全删, done.txt 清零(备份 done.txt.bak), 全量重跑 43 帧(~16分/帧)
- 分支预案: 不花屏→VAEDecode 定稿并回写档案/GitHub 包; 仍花屏→第二补丁 fp8_e4m3fn→default(+1G 内存)
- 多窗口规矩(11-19 定): 单窗口主刀, 会诊结论只复制文字过来; 省额度=文字命令查进度/攒着问/少发截图
- 脚本三件(手机 Termux): ~/vidwork/pipi_batch.py(v1.2) + watchdog.sh(v3) + fix_all.sh
  最新版副本存于 /workspace/手机脚本包/ + 说明书写明血泪教训
- 断点续跑机制: done.txt 账本, 每帧完成记一行, 死亡只损失在算的那帧
- 守夜人 v3: 每轮强制换全新服务器(治"活僵尸"), 连续3帧失败批量自动退场
- 进度查看: `cat ~/vidwork/done.txt | wc -l` (只认账本, 别信日志尾巴)
- 速率: 约 20 分/帧, 43 帧约 14 小时; 成品 ~/vidwork/pipi_done.mp4

### C. 排障定案(三天三大案)
1. **空400拒收**(11-16): multipart 少写每字段前的 --boundary 分界行 → 服务器收不到
   image 字段。修复: api() 补分界行(见 pipi_batch.py v1.2, 勿回退)
2. **全军500**(11-17): 鸿蒙冻进程→网络流错位, 服务器日志 InvalidHeader: b'--boundary'。
   病根治法: 用户已在系统设置 Termux 自启动/关联启动/后台活动全开
3. **假象迷惑**(贯穿): Python 缓冲导致日志撒谎(改 python -u); 旧会话文件计数混淆
   (改 done.txt 账本制)

### D. 用户情况更新
- 用户积分快耗尽, 可能换账号开新会话 → 交接靠本文件 + /workspace/手机脚本包/
- 用户已有 GitHub 账号 zhongguogit(令牌勿再索要, 用完即删)
