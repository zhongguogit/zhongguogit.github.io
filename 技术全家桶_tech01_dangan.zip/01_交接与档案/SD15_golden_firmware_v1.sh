#!/data/data/com.termux/files/usr/bin/bash
# ====================================================================
#  SD1.5 黄金固件 v1 —— 把任何安卓手机从零装到"能出图、不花屏"
#  依据: GOLDEN v1 (2026-11-10 破案; 第00047号图=人像, 验证通过)
#  适用: Android/HarmonyOS 的 Termux, ARM64, 建议 6G 内存以上
#
#  用法: bash sd15_golden_firmware_v1.sh <阶段>
#    0 = 体检      1 = 基础包    2 = torch+venv   3 = ComfyUI 本体
#    4 = 模型四件  5 = 黄金工作流 6 = 启动出图
#    all = 按 1→5 连跑 (每阶段结束会停, 看一眼没问题再敲下一个)
#
#  铁律: 所有模型文件必须通过 sha256 指纹验收, 对不上 = 拒装。
#        固件不信任任何下载源 —— 这就是"装完必不花屏"的保证。
# ====================================================================
set -u
M_CU="$HOME/comfyui/ComfyUI"
M_VP="$HOME/comfyui/venv"
M_GF="$HOME/golden_cfg"
SRC="/sdcard/golden_models"          # 手动放模型的位置(从旧手机拷来放这里)
TUNA="https://pypi.tuna.tsinghua.edu.cn/simple"
GH="https://gh-proxy.com/https://github.com"
HFM="https://hf-mirror.com"

# ---------- 指纹户口 (一个字符都不能改) ----------
SHA_Q4="b8944e9fe0b69b36ae1b5bb0185b3a7b8ef14347fe0fa9af6c64c4829022261f"
SZ_Q4=1566768416
SHA_CLIP="77795e2023adcf39bc29a884661950380bd093cf0750a966d473d1718dc9ef4e"
SZ_CLIP=246144864
SHA_VAE="735e4c3a447a3255760d7f86845f09f937809baa529c17370d83e4c3758f3c75"
SZ_VAE=334641190
SHA_FP16="ddf329f94df384f18665372514cbd6310a898cfd845b7f4f9228c023d9865cc1"

# ---------- 下载源 ----------
# VAE: 官方源已验证(大小+指纹与黄金户口一字不差), 可以直接下
URL_VAE="$HFM/stabilityai/sd-vae-ft-mse-original/resolve/main/vae-ft-mse-840000-ema-pruned.safetensors"
# Q4_0 与 CLIP: 公开仓库版本与黄金指纹不符, 属孤本, 留空 = 只允许从旧手机导入。
# 如果将来找到指纹完全一致的公开源, 把直链填到下面引号里即可。
URL_Q4=""
URL_CLIP=""

say(){ echo ""; echo "===== $1 ====="; }
die(){ echo ""; echo "!!!! $1"; echo "!!!! 流程在这里停下, 修好再重跑本阶段"; exit 1; }

verify(){ # verify <文件> <期望sha> <期望字节数> <名称>
  local f="$1" want="$2" sz="$3" name="$4" got n
  [ -f "$f" ] || { echo "[$name] 不存在: $f"; return 1; }
  n=$(stat -c%s "$f" 2>/dev/null || wc -c < "$f")
  [ "$n" = "$sz" ] || echo "[$name] 字节数 $n != 期望 $sz (继续看指纹)"
  got=$(sha256sum "$f" | cut -d' ' -f1)
  if [ "$got" = "$want" ]; then echo "[$name] 指纹通过 ✓"; return 0; fi
  echo "[$name] 指纹不符! got=$got"; return 1
}

get_model(){ # get_model <目标> <sha> <大小> <名称> <URL>
  local dst="$1" sha="$2" sz="$3" name="$4" url="$5" base
  base=$(basename "$dst")
  if [ -f "$dst" ] && verify "$dst" "$sha" "$sz" "$name"; then return 0; fi
  if [ -f "$SRC/$base" ]; then
    echo "[$name] 从 $SRC 导入..."
    cp "$SRC/$base" "$dst" && verify "$dst" "$sha" "$sz" "$name" && return 0
  fi
  if [ -n "$url" ]; then
    echo "[$name] 从官方源下载(大文件, 请耐心)..."
    curl -L --fail --retry 3 -o "$dst.part" "$url" || die "[$name] 下载失败, 网络问题请重试本阶段"
    mv "$dst.part" "$dst" && verify "$dst" "$sha" "$sz" "$name" && return 0
  fi
  echo "[$name] 拿不到! 两条路:"
  echo "  a) 从旧手机把 $base 拷到 $SRC/ 然后重跑本阶段"
  echo "  b) 找到指纹一致的公开直链, 填进本固件顶部 URL_${name} 变量"
  return 1
}

# ---------------- 阶段 0: 体检 ----------------
stage0(){
  say "阶段0 体检"
  [ -n "${TERMUX_VERSION:-}" ] || [ "$PREFIX" = "/data/data/com.termux/files/usr" ] \
    || die "这里不是 Termux! 请在手机 Termux 里运行本固件"
  echo "架构: $(uname -m)   内存:"; free -h | head -2
  [ -d /sdcard ] && echo "共享存储 /sdcard ✓" || echo "/sdcard 不可见 → 先跑: termux-setup-storage (问 y 答 y)"
  curl -sI --max-time 15 "$HFM" >/dev/null && echo "网络 hf-mirror ✓" || echo "网络: hf-mirror 暂时不通, 检查代理/换网"
  echo "体检完, 没有 !!!! 报错就继续 阶段1"
}

# ---------------- 阶段 1: 基础包 ----------------
stage1(){
  say "阶段1 基础包(几分钟)"
  termux-setup-storage 2>/dev/null
  pkg update -y && pkg install -y python git || die "pkg 装基础包失败, 检查网络重跑"
  mkdir -p "$SRC" "$M_GF" "$HOME/comfyui"
  echo "基础包 ✓  (模型中转目录: $SRC)"
}

# ---------------- 阶段 2: torch + venv ----------------
stage2(){
  say "阶段2 torch + venv (TUR 源, 十几分钟, 手机会发烫属正常)"
  pkg install -y tur-repo || die "tur-repo 装不上"
  pkg install -y python-torch || die "python-torch 装不上(这是验证过的 torch 来源, 不走 pip)"
  [ -d "$M_VP" ] || python -m venv --system-site-packages "$M_VP" \
    || die "venv 建不了"
  "$M_VP/bin/python" -c "import torch; print('torch', torch.__version__, '导入 ✓')" \
    || die "venv 里看不到 torch: 确认 venv 是用 --system-site-packages 建的"
  echo "torch + venv ✓"
}

# ---------------- 阶段 3: ComfyUI 本体 ----------------
stage3(){
  say "阶段3 ComfyUI 本体"
  [ -d "$M_CU/.git" ] || git clone "$GH/comfyanonymous/ComfyUI" "$M_CU" || die "clone 失败, 换网重跑"
  grep -ivE "^(torch|torchvision|torchaudio)[=<>~! ]" "$M_CU/requirements.txt" > /tmp/req_no_torch.txt
  "$M_VP/bin/pip" install -r /tmp/req_no_torch.txt -i "$TUNA" || die "依赖装失败, 重跑本阶段"
  "$M_VP/bin/pip" install "gguf==0.19.0" safetensors -i "$TUNA" || die "gguf/safetensors 装失败"
  echo "ComfyUI 本体 + 依赖 ✓  (torch 系全部来自 pkg, 不被 pip 覆盖)"
}

# ---------------- 阶段 4: 模型四件 ----------------
stage4(){
  say "阶段4 模型四件(过指纹验收)"
  mkdir -p "$M_CU/models/unet" "$M_CU/models/clip" "$M_CU/models/vae"
  get_model "$M_CU/models/unet/sd15_Q4_0.gguf" "$SHA_Q4" "$SZ_Q4" "Q4_0" "$URL_Q4" \
    || die "Q4_0 未通过"
  get_model "$M_CU/models/clip/sd15_clip_l.safetensors" "$SHA_CLIP" "$SZ_CLIP" "CLIP" "$URL_CLIP" \
    || die "CLIP 未通过"
  get_model "$M_CU/models/vae/vae-ft-mse-840000-ema-pruned.safetensors" "$SHA_VAE" "$SZ_VAE" "VAE" "$URL_VAE" \
    || die "VAE 未通过"

  # fp16: 有且指纹对 → 跳过; 否则现场再生(几分钟, 纯CPU)
  local F16="$M_CU/models/unet/sd15_dequant_fp16.safetensors"
  if [ -f "$F16" ] && verify "$F16" "$SHA_FP16" "1719000000" "fp16(现成)" 2>/dev/null; then
    echo "fp16 现成且指纹对, 跳过再生"
  else
    [ -f "$F16" ] && echo "fp16 指纹对不上或缺失 → 重新再生覆盖"
    cat > "$M_GF/dequant_rebuild.py" <<'PYEOF'
import os, numpy as np, gguf
from gguf import GGUFReader
from gguf.quants import dequantize
from gguf import GGMLQuantizationType as QT
from safetensors.numpy import save_file
BASE = os.path.expanduser("~/comfyui/ComfyUI/models/unet")
SRC  = os.path.join(BASE, "sd15_Q4_0.gguf")
DST  = os.path.join(BASE, "sd15_dequant_fp16.safetensors")
rd = GGUFReader(SRC)
out = {}
for t in rd.tensors:
    if t.tensor_type == QT.Q4_0:
        raw = t.data.reshape(-1, 18)                       # 每块: 2字节fp16 scale + 16字节低4位包
        d  = raw[:, :2].copy().view(np.float16).reshape(-1).astype(np.float32)
        qs = raw[:, 2:]
        w  = np.empty((raw.shape[0], 32), np.float32)
        w[:, :16] = (qs & 0x0F).astype(np.int8) - 8        # 低4位在前
        w[:, 16:] = (qs >> 4).astype(np.int8) - 8          # 高4位在后
        w *= d.reshape(-1, 1)
        out[t.name] = w.reshape(tuple(reversed([int(x) for x in t.shape]))).astype(np.float16)
    else:
        a = t.data
        if a.dtype == np.uint8: a = a.view(np.float16)
        out[t.name] = a.astype(np.float16).reshape(tuple(reversed([int(x) for x in t.shape])))
print("参数量(百万):", round(sum(v.size for v in out.values()) / 1e6, 1), " 张量数:", len(out))
save_file(out, DST)
print("已写出:", DST)
PYEOF
    "$M_VP/bin/python" "$M_GF/dequant_rebuild.py" || die "再生脚本跑失败"
    sha256sum "$F16"
    got=$(sha256sum "$F16" | cut -d' ' -f1)
    if [ "$got" = "$SHA_FP16" ]; then echo "fp16 指纹 = 黄金原件 ✓ (位级复刻)"
    else echo "注意: fp16 指纹与黄金原件不同(数值路径微小差异), 用出图验收兜底"; fi
  fi
  echo "模型四件 ✓"
}

# ---------------- 阶段 5: 黄金工作流 ----------------
stage5(){
  say "阶段5 黄金工作流(UNETLoader=sd15_dequant_fp16 + fp8_e4m3fn ← 命门)"
  mkdir -p "$M_CU/user/default/workflows"
  cat > "$M_CU/user/default/workflows/黄金工作流_v1.json" <<'JSONEOF'
{
  "last_node_id": 31,
  "last_link_id": 18,
  "nodes": [
    {"id": 31, "type": "UNETLoader", "pos": [1880, -594], "size": [270, 82], "flags": {}, "order": 3, "mode": 0,
     "inputs": [], "outputs": [{"name": "MODEL", "type": "MODEL", "links": [18]}],
     "properties": {"Node name for S&R": "UNETLoader"},
     "widgets_values": ["sd15_dequant_fp16.safetensors", "fp8_e4m3fn"]},
    {"id": 2, "type": "CLIPLoader", "pos": [82, -107], "size": [320, 160], "flags": {}, "order": 0, "mode": 0,
     "inputs": [], "outputs": [{"name": "CLIP", "type": "CLIP", "slot_index": 0, "links": [2, 4]}],
     "properties": {"Node name for S&R": "CLIPLoader"},
     "widgets_values": ["sd15_clip_l.safetensors", "stable_diffusion", "cpu"]},
    {"id": 27, "type": "VAELoader", "pos": [760, 477], "size": [270, 58], "flags": {}, "order": 2, "mode": 0,
     "inputs": [], "outputs": [{"name": "VAE", "type": "VAE", "links": [16]}],
     "properties": {"Node name for S&R": "VAELoader"},
     "widgets_values": ["vae-ft-mse-840000-ema-pruned.safetensors"]},
    {"id": 5, "type": "EmptyLatentImage", "pos": [-138, 502], "size": [320, 106], "flags": {}, "order": 1, "mode": 0,
     "inputs": [], "outputs": [{"name": "LATENT", "type": "LATENT", "slot_index": 0, "links": [6]}],
     "title": "Latent 尺寸", "properties": {"Node name for S&R": "EmptyLatentImage"},
     "widgets_values": [384, 384, 1]},
    {"id": 3, "type": "CLIPTextEncode", "pos": [617, -460], "size": [340, 120], "flags": {}, "order": 4, "mode": 0,
     "inputs": [{"name": "clip", "type": "CLIP", "link": 2}],
     "outputs": [{"name": "CONDITIONING", "type": "CONDITIONING", "slot_index": 0, "links": [17]}],
     "title": "正向提示词", "properties": {"Node name for S&R": "CLIPTextEncode"},
     "widgets_values": ["a young chinese woman in ancient costume, cinematic lighting, film still, highly detailed"]},
    {"id": 4, "type": "CLIPTextEncode", "pos": [523, 316], "size": [340, 120], "flags": {}, "order": 5, "mode": 0,
     "inputs": [{"name": "clip", "type": "CLIP", "link": 4}],
     "outputs": [{"name": "CONDITIONING", "type": "CONDITIONING", "slot_index": 0, "links": [5]}],
     "title": "负向提示词", "properties": {"Node name for S&R": "CLIPTextEncode"},
     "widgets_values": ["ugly, deformed, blurry, noisy, pixelated, mutated"]},
    {"id": 6, "type": "KSampler", "pos": [1338, -567], "size": [320, 280], "flags": {}, "order": 6, "mode": 0,
     "inputs": [
       {"name": "model", "type": "MODEL", "link": 18},
       {"name": "positive", "type": "CONDITIONING", "link": 17},
       {"name": "negative", "type": "CONDITIONING", "link": 5},
       {"name": "latent_image", "type": "LATENT", "link": 6}],
     "outputs": [{"name": "LATENT", "type": "LATENT", "slot_index": 0, "links": [12]}],
     "title": "采样", "properties": {"Node name for S&R": "KSampler"},
     "widgets_values": [123456, "fixed", 20, 7, "dpmpp_2m", "karras", 1]},
    {"id": 17, "type": "VAEDecodeTiled", "pos": [1171, 250], "size": [264, 150], "flags": {}, "order": 7, "mode": 0,
     "inputs": [{"name": "samples", "type": "LATENT", "link": 12}, {"name": "vae", "type": "VAE", "link": 16}],
     "outputs": [{"name": "IMAGE", "type": "IMAGE", "links": [14]}],
     "properties": {"Node name for S&R": "VAEDecodeTiled"},
     "widgets_values": [320, 32, 64, 8]},
    {"id": 9, "type": "SaveImage", "pos": [1659, 252], "size": [320, 280], "flags": {}, "order": 8, "mode": 0,
     "inputs": [{"name": "images", "type": "IMAGE", "link": 14}],
     "outputs": [], "properties": {"Node name for S&R": "SaveImage"},
     "widgets_values": ["ComfyUI"]}
  ],
  "links": [
    [2, 2, 0, 3, 0, "CLIP"], [4, 2, 0, 4, 0, "CLIP"],
    [5, 4, 0, 6, 2, "CONDITIONING"], [6, 5, 0, 6, 3, "LATENT"],
    [12, 6, 0, 17, 0, "LATENT"], [14, 17, 0, 9, 0, "IMAGE"],
    [16, 27, 0, 17, 1, "VAE"], [17, 3, 0, 6, 1, "CONDITIONING"],
    [18, 31, 0, 6, 0, "MODEL"]
  ],
  "groups": [], "config": {}, "extra": {}, "version": 0.4
}
JSONEOF
  cp "$M_CU/user/default/workflows/黄金工作流_v1.json" "$M_GF/" 2>/dev/null
  "$M_VP/bin/python" -c "import json;json.load(open('$M_CU/user/default/workflows/黄金工作流_v1.json'));print('工作流 JSON 合法 ✓')" \
    || die "工作流 JSON 坏了"
  { echo "== SD1.5 黄金固件安装记录 $(date '+%F %T') =="
    echo "Q4_0  $SHA_Q4"; echo "CLIP  $SHA_CLIP"; echo "VAE   $SHA_VAE"; echo "fp16  $SHA_FP16"
    echo "命门: UNETLoader weight_dtype = fp8_e4m3fn (fp16 直载=内存秒杀)"
    echo "禁忌: GGUF 不进 UnetLoaderGGUF; 禁 --force-fp32; 模型四件冻结"
  } > "$M_GF/安装记录.txt"
  echo "黄金工作流 ✓"
}

# ---------------- 阶段 6: 启动出图 ----------------
stage6(){
  say "阶段6 启动出图"
  termux-wake-lock
  pkill -9 -f main.py 2>/dev/null; sleep 2
  setsid nohup "$M_VP/bin/python" "$M_CU/main.py" --cpu --listen 0.0.0.0 >"$HOME/comfyui/comfy.log" 2>&1 </dev/null & disown
  echo "服务器启动中(90秒)... 手机保持前台, 别锁屏"
  sleep 90
  grep -a "To see the GUI go to" "$HOME/comfyui/comfy.log" \
    && echo "启动 ✓ 浏览器开 http://127.0.0.1:8188 载入[黄金工作流_v1]" \
    || { echo "90秒还没就绪, 再等2分钟后跑:"; tail -20 "$HOME/comfyui/comfy.log"; }
  echo ""
  echo "出图纪律: 关其它后台(尤其浏览器) → Queue → 立刻退浏览器 → Termux 前台不锁屏 → 等约10分钟"
  echo "查结果: ls -lt $M_CU/output/ | head -3"
  echo "看图:   termux-open \"\$(ls -t $M_CU/output/*.png | head -1)\""
  echo ""
  echo "最终验收(唯一标准): 同 seed 123456 出的图是【人像】不是彩色碎渣 → 固件安装成功"
}

case "${1:-}" in
  0) stage0;; 1) stage1;; 2) stage2;; 3) stage3;; 4) stage4;; 5) stage5;; 6) stage6;;
  all) stage1; stage2; stage3; stage4; stage5;;
  *) sed -n '2,20p' "$0"; echo ""; echo "例: bash $0 0   (先体检, 再一阶段一阶段来)";;
esac
