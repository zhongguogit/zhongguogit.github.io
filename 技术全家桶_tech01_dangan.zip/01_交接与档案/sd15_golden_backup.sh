# ================================================================
#  SD1.5 黄金配置 · 备份固件一键执行  (GOLDEN v1, 2026-11-10)
#  只读黄金文件, 不改不删; 产出两套独立备份
# ================================================================
mkdir -p ~/golden_cfg

# ---- 1. 全案记录 ----
cat > ~/golden_cfg/RECORD.txt <<'EOF_RECORD'
====================================================
SD1.5 手机(Termux)出图 · 全案记录(细化版) 与 黄金配置
GOLDEN v1 - 2026-11-10
状态: 流水线已跑通(00047 完整执行 20 步), 画质最终判定待确认
====================================================

[0] 环境户口
  设备: 安卓手机(HarmonyOS 4.0), ARM 八核 aarch64
  内存: 总 5.5Gi / 日常可用约 1.7Gi / Swap 2.7Gi(常态已用 1.5Gi)
  运行时: Termux + python venv + ComfyUI 纯 CPU 模式
  路径: ComfyUI = ~/comfyui/ComfyUI   venv = ~/comfyui/venv   日志 = ~/comfyui/comfy.log
  网络: ghfast.top SSL 时好时坏; 稳定镜像 = gh-proxy.com / hf-mirror.com / 清华 pip 源
  已知不可装: pydantic-core (maturin 需 Rust 编译, Android 报
    "Failed to determine Android API level") —— 非必需组件, 与出图无关

[1] 案发与假模型清剿
  现象: SD1.5 三件套出图 = 高饱和彩色噪点(花屏/碎渣), 多日多参不愈
  查获假货: sd_turbo_q8_0.gguf 实为 SD2.1 血统(文本维度 1024, SD1.5 应为 768)
  同时纠错: CLIPLoader 类型被误设(应为 stable_diffusion);
            VAE 误选 160M 小文件(应为 334M 官方 vae-ft-mse-840000)
  行动: 全部换成官方文件, 三件套血统一致

[2] 文件户口(黄金四件, 均在 ~/comfyui/ComfyUI/models/ 下)
  unet/sd15_Q4_0.gguf
    1,566,768,416 字节
    sha256 = b8944e9fe0b69b36ae1b5bb0185b3a7b8ef14347fe0fa9af6c64c4829022261f
    (= 官方指纹一字不差, 文件清白实锤)
    下载实录: ghfast.top 失败(SSL) 自动切 gh-proxy.com 成功; 后又整包重下并校验一致
  unet/sd15_dequant_fp16.safetensors   约 1.7GB   (黄金产出物)
    由上面的 Q4_0 离线反量化生成
    686 个张量全拆净: Q4_0 587 + F16 99, 总参数 859.5M, 与 SD1.5 unet 标准体量完全对账
  clip/sd15_clip_l.safetensors         246,144,864 字节
  vae/vae-ft-mse-840000-ema-pruned.safetensors   334,641,190 字节
  废弃文件(建议删除, 共约 3.2G, 删前先确认备份完成):
    unet/sd_turbo_fp16.safetensors (1.7G, SD2.1 血统)
    unet/sd_turbo_q8_0.gguf (878M, SD2.1 血统)
    clip/clip_l.safetensors (680M, SD2 时代 OpenCLIP-H, 用不上)
    vae/vae-ft-ema.safetensors 与 vae/sd15_vae.safetensors (各约 320M, 未验证)

[3] 插件与库状态
  custom_nodes/ComfyUI-GGUF-main (新版; 目录名带 -main 不影响加载)
  python 库 gguf 0.19.0 (venv 内)
  关键日志: loaded in compatibility mode 'sd.cpp' [arch:sd1]
            gguf qtypes: Q4_0 (587), F16 (99)
  读 loader.py 源码结论: 对 SD1.5 架构插件不做任何改名/转置/重排,
    "兼容模式"只是贴标签, 不存在"转换出错"的环节
  --force-fp32 启动旗子: 对 CLIP dtype 无效(日志仍 fp16), 对 GGUF/fp8 无意义
    → 已从启动命令移除

[4] 排除法实验链(每一环的命令、现象与判决)

  实验 A · 零潜图直解
    做法: 画布上 EmptyLatentImage 的 LATENT 直连 VAEDecodeTiled 的 samples(绕过 KSampler)
    结果: 出干净暖灰色图
    判决: VAE 无罪, VAEDecodeTiled 无罪, "画布残留干扰"论出局

  实验 B · cfg=1 单通道
    做法: KSampler 的 cfg 改 1(只跑正向单通道, 跳过负向差值机制)
    结果: 平滑橙色渐变
    判决: unet 主干无 NaN 级崩溃

  实验 C · CLIP 体检脚本
    要点(重写脚本时必须遵守):
      - 先 comfy.options.enable_args_parsing(True) 再 import comfy.cli_args
        (该版 ComfyUI 默认不解析 argv, 否则 --cpu 不生效)
      - load_clip 用位置参数: ([路径], None, comfy.sd.CLIPType.STABLE_DIFFUSION, {})
      - encode_from_tokens 旧版无 return_pooled 参数, 需 TypeError 降级
    结果四行全绿: 无 NaN / 无 Inf / absmax=33.06 / fp16==fp32
      real mean -0.1134 与 empty mean -0.1088 不同(编码器真的在干活)
    判决: CLIP 无罪, "fp16 溢出"论出局

  实验 D · 正负同文本 + cfg=7
    做法: 正负两个 CLIPTextEncode 填同一句话, cfg 保持 7
    结果: 碎渣
    判决: 定罪方向锁定 "unet 消化真实文本语境" 的环节
      = GGUF 插件"边跑边反量化"的运行时路径

  实验 E · 第三个文件交叉验证
    做法: 换 cyberrealistic 462MB (city96 标准量化, 不进兼容模式)
    结果: 仍花屏
    判决: "兼容模式转换出错"论被双杀(源码+实验);
      三种文件共用的插件运行时代码成为唯一嫌疑

  实验 F · 指纹验证
    做法: 重新下载 sd15_Q4_0.gguf 并算 sha256
    结果: b8944e9f...2261f 与官方一字不差
    判决: 文件清白实锤, "文件损坏"论出局

  实验 G · 离线反量化 (脚本全文存档为 dequant_rebuild.py)
    Q4_0 公式: 每 32 个权重一块 = 2 字节 fp16 缩放系数
      + 16 字节半字节(低 4 位 = 前 16 个权重, 高 4 位 = 后 16 个权重,
      数值减 8, 乘缩放系数)
    运行实录: 磁盘余 31.13GB; 每 100 张量报进度;
      终报 Q4_0 587 / F16 99 / 总参数 859.5M; 保存成功
    (numpy non-writable UserWarning 是 mmap 正常现象, 无害)

  实验 H · fp16 直载 → 秒崩
    现象: 点运行后 1 秒内浏览器报
      "提示执行失败 TypeError: Failed to fetch" + "无法获取服务器日志"
      = 服务器进程被杀(非 ComfyUI 报错)
    free -h 实录: Mem total 5.5Gi / used 3.8Gi / available 1.7Gi
                  Swap 2.7Gi total / 1.5Gi used
    判定: fp16 需整块 1.7G + 运行开销 0.6G ≈ 2.4G > 可用 1.7G
      → 安卓低内存杀手瞬间击杀

  实验 I · fp8 降档 → 流水线复活
    做法: UNETLoader 的 weight_dtype 改 fp8_e4m3fn
      (权重存储压到约 860M, 计算时每层临时转回, 精度损失小于 Q4_0)
    结果: 00047 完整执行 20 步, ComfyUI_00047_.png/.json 落盘
    判决: 内存关通过, 流水线跑通

[5] 黄金工作流 (= output/ComfyUI_00047_.json, 一字不改)
  UNETLoader      : sd15_dequant_fp16.safetensors
                    weight_dtype = fp8_e4m3fn          ← 命门, 不能改回 default
  CLIPLoader      : sd15_clip_l.safetensors / stable_diffusion / cpu
  VAELoader       : vae-ft-mse-840000-ema-pruned.safetensors
  正向提示词       : a young chinese woman in ancient costume, cinematic lighting, film still, highly detailed
  负向提示词       : ugly, deformed, blurry, noisy, pixelated, mutated
  EmptyLatentImage: 384 x 384, batch 1
  KSampler        : seed 123456 fixed / steps 20 / cfg 7 / dpmpp_2m / karras / denoise 1.0
  VAEDecodeTiled  : tile 320 / overlap 32
  SaveImage       : 文件名前缀 ComfyUI

[6] 启动与出图标准动作(逐字)
  启动:
    termux-wake-lock
    pkill -9 -f main.py; sleep 2
    setsid nohup ~/comfyui/venv/bin/python ~/comfyui/ComfyUI/main.py --cpu --listen 0.0.0.0 >~/comfyui/comfy.log 2>&1 </dev/null & disown; sleep 90
  出图: 关后台 → 刷新页 → Queue → 立刻退浏览器 → Termux 前台不锁屏 → 等 10 分钟
  查结果: ls -lt ~/comfyui/ComfyUI/output/ | head -3
  看图:   termux-open "$(ls -t ~/comfyui/ComfyUI/output/*.png | head -1)"
  查状态: grep -aE "model weight dtype|manual cast|loaded completely|got prompt|prompt executed" ~/comfyui/comfy.log | tail -8

[7] 最终判决
  真凶: ComfyUI-GGUF 插件"边跑边反量化"运行时路径 × Termux torch 数值出错
  解法: 离线拆包(Q4_0 → 标准 fp16 文件) + fp8_e4m3fn 低内存载入, 绕开插件运行时
  铁证: ComfyUI_00047_.png / .json; 产物参数量 859.5M 完全对账; Q4_0 文件 sha256 清白

[8] 红线(不搞乱守则)
  x GGUF 文件不再进 UnetLoaderGGUF 节点(除非 MISSION.txt 观察清单里的修复落地)
  x 黄金四件不改名 / 不覆盖 / 不删除
  x 实验一律副本 + test_ 前缀 + 一次一变量
  x 回滚 = 画布重新拖入 ComfyUI_00047_.json
  (升级换代流程见 MISSION.txt)
EOF_RECORD

# ---- 2. 长期任务章程 ----
cat > ~/golden_cfg/MISSION.txt <<'EOF_MISSION'
====================================================
SD1.5 手机出图 · 长期任务章程 (延续用总纲)
GOLDEN v1 · 立卡日 2026-11-10
====================================================

[使命]
  在这台安卓手机上, 长期维护并持续改进 SD1.5 本地文生图流水线:
  能出图 → 出好图 → 出得更快、更省内存。
  任何改动都不得破坏现有能力。

[延续机制 —— 每次新对话怎么接上]
  1. 把本文件 + RECORD.txt 交给 AI (或说: 先读这两份档案再动手)
  2. 报告当前版本号与最新基准图编号
  3. AI 的一切建议必须先过[实验守则]再执行

[版本制度]
  当前版本: GOLDEN v1 (2026-11-10, 基准图 ComfyUI_00047_.png)
  换代流程:
    候选技术 → 在 test_ 副本上验证 → 与当前黄金版同 seed 同提示词对比
    → 胜出判定: 更快 / 更省内存 / 画质更好, 得其一而不伤其余
    → 冻结为新版本(如 GOLDEN v2), 归档旧版, 更新 RECORD 与 MISSION 两份档案,
       生成新基准图
  失败处理: 删除 test_ 副本, 黄金版原样不动

[实验守则]
  1. 黄金文件不改名 / 不覆盖 / 不删除
  2. 一次只改一个变量
  3. 实验文件一律加 test_ 前缀, 失败立即删除
  4. 每次实验留档: 命令 + 结果 + 结论, 追加进 RECORD.txt
  5. 回滚: 画布拖入 ComfyUI_00047_.json 即恢复

[技术升级观察清单 —— 出现更先进技术时立即评估, 确认更优立即换代]
  1. city96/ComfyUI-GGUF 新版本:
     若修复了 Termux 上的运行时反量化数值问题,
     GGUF 直载回归(内存 860M → 约 500M) → 立即换代
  2. ComfyUI 本体更新: 原生 GGUF / 低内存载入改进 → 评估
  3. Termux python-torch 升级: fp16/fp8 数值与性能可能变化
     → 升级后先重跑 CLIP 体检脚本对账, 再跑基准图对比
  4. SD1.5 血统的蒸馏加速模型 (LCM-SD1.5 等, 4~8 步出图):
     认准 SD1.5 血统(文本维度必须 768), 严禁 SD2/SDXL 血统
  5. 更优量化格式 (原生 fp8 文件等): 内存再降是第一优先评估项
  6. sd.cpp (stable-diffusion.cpp) Termux 命令行路线:
     该路线已验证能出图(30 张); 若 ComfyUI 路线反复受损, 升为主路线
  7. 更好的 CLIP / VAE 组合: 同 seed 同提示词对比画质后决定

[当前待办]
  1. 判定 00047 画质(截图交 AI) → 决定下一步走[提质量]还是[再排障]
  2. 清理废弃模型腾空间(清单见 RECORD.txt [2], 约 3.2G; 先确认备份完成)
  3. 提质量路线(一次一步): steps 20→24 → 试 euler_a 对比 →
     提示词加权 (重点词:1.2) → 448x448 试水(512 需过内存关)

[红线]
  x 任何操作不得违反[实验守则]
  x 换代前必须完成备份(两套副本, 见 RESTORE.sh)
  x 章程与记录必须随换代同步更新, 版本号必须递增
====================================================
EOF_MISSION

# ---- 3. 再生脚本: 从 Q4_0 重建 fp16 黄金文件 ----
cat > ~/golden_cfg/dequant_rebuild.py <<'EOF_PY'
import sys, os, hashlib, shutil
import torch, gguf
from safetensors.torch import save_file

HOME = "/data/data/com.termux/files/home"
P   = HOME + "/comfyui/ComfyUI/models/unet/sd15_Q4_0.gguf"
OUT = HOME + "/comfyui/ComfyUI/models/unet/sd15_dequant_fp16.safetensors"
OFFICIAL = "b8944e9fe0b69b36ae1b5bb0185b3a7b8ef14347fe0fa9af6c64c4829022261f"

sz = os.path.getsize(P)
print("文件大小:", sz, "(应为 1566768416)")
h = hashlib.sha256()
with open(P, "rb") as f:
    for c in iter(lambda: f.read(1 << 22), b""):
        h.update(c)
d = h.hexdigest()
print("sha256 :", d)
print("官方   :", OFFICIAL)
if d != OFFICIAL:
    print("== 指纹不一致: 文件损坏! 脚本停止, 先重新下载 ==")
    sys.exit(1)
print("== 指纹一致, 文件完好, 开始反量化(约 3~5 分钟) ==")

free = shutil.disk_usage(HOME).free / 1e9
print("剩余磁盘: %.2f GB" % free)
if free < 2.5:
    print("空间不足, 先删废模型再跑")
    sys.exit(1)

reader = gguf.GGUFReader(P)
PREFIX = "model.diffusion_model."
sd, nq, nf, npar = {}, 0, 0, 0
for t in reader.tensors:
    if not t.name.startswith(PREFIX):
        continue
    key = t.name[len(PREFIX):]
    logical = tuple(int(v) for v in reversed(t.shape))
    if t.tensor_type == gguf.GGMLQuantizationType.Q4_0:
        a = torch.from_numpy(t.data.reshape(-1, 18)).contiguous()
        scales = a[:, :2].contiguous().view(torch.float16).float()
        qs = a[:, 2:]
        lo = (qs & 0x0F).to(torch.int16) - 8
        hi = (qs >> 4).to(torch.int16) - 8
        w = torch.cat([lo, hi], dim=1).float() * scales
        nq += 1
    elif t.tensor_type == gguf.GGMLQuantizationType.F16:
        w = torch.from_numpy(t.data).reshape(logical).float()
        nf += 1
    else:
        print("不认识的量化类型", t.tensor_type, "在", t.name, "—— 把输出发给 AI")
        sys.exit(1)
    w = w.reshape(logical).to(torch.float16).contiguous()
    sd[key] = w
    npar += w.numel()
    if len(sd) % 100 == 0:
        print("已完成", len(sd), "个张量")

print("Q4_0 张量:", nq, "(应 587)   F16 张量:", nf, "(应 99)")
print("总参数量: %.1f M" % (npar / 1e6))
save_file(sd, OUT, metadata={"format": "pt"})
print("已保存:", OUT)
print("全部完成。启动 ComfyUI, UNETLoader 选 sd15_dequant_fp16.safetensors + fp8_e4m3fn")
EOF_PY

# ---- 4. 恢复指引 ----
cat > ~/golden_cfg/RESTORE.sh <<'EOF_RS'
#!/data/data/com.termux/files/usr/bin/bash
# =====================================================
#  GOLDEN v1 恢复指引 —— 大工程, 按步骤手动执行, 别盲跑
#  (换机 / 重装 Termux / 文件损坏时才用)
# =====================================================
# [1] 装基础包
#     pkg update -y && pkg install python git -y
#     torch 来自 pkg 而非 pip: pkg install python-torch (TUR 源)
# [2] 对照安装库: 看本目录 pip_freeze.txt 与 pkg_list.txt
#     普通 pip 库: ~/comfyui/venv/bin/pip install 库名 -i https://pypi.tuna.tsinghua.edu.cn/simple
# [3] 取回 ComfyUI
#     git clone https://gh-proxy.com/https://github.com/comfyanonymous/ComfyUI ~/comfyui/ComfyUI
# [4] 放回黄金模型(用 models_inventory.txt 核对字节数):
#     sd15_Q4_0.gguf          -> models/unet/
#        sha256 必须 = b8944e9fe0b69b36ae1b5bb0185b3a7b8ef14347fe0fa9af6c64c4829022261f
#     sd15_clip_l.safetensors -> models/clip/
#     vae-ft-mse-840000-ema-pruned.safetensors -> models/vae/
# [5] 重建 fp16 黄金文件(若丢失):
#     pkill -9 -f main.py
#     ~/comfyui/venv/bin/python ~/golden_cfg/dequant_rebuild.py
# [6] 启动(逐字):
#     termux-wake-lock
#     setsid nohup ~/comfyui/venv/bin/python ~/comfyui/ComfyUI/main.py --cpu --listen 0.0.0.0 >~/comfyui/comfy.log 2>&1 </dev/null & disown; sleep 90
# [7] 工作流: 浏览器拖入本目录 ComfyUI_00047_.json
#     UNETLoader 的 weight_dtype 认准 fp8_e4m3fn
# [8] 恢复后出一张图与基准图对比, 确认 GOLDEN 复活
# =====================================================
echo "本文件是恢复指引文档, 用以下命令查看:"
echo "less ~/golden_cfg/RESTORE.sh"
EOF_RS
chmod +x ~/golden_cfg/RESTORE.sh

# ---- 5. 收集现场证据与户口 ----
cp ~/comfyui/ComfyUI/output/ComfyUI_00047_.json ~/golden_cfg/ 2>/dev/null && echo "已收档: 00047 工作流 JSON"
cp ~/comfyui/ComfyUI/output/ComfyUI_00047_.png ~/golden_cfg/ 2>/dev/null && echo "已收档: 00047 基准图 PNG"
ls -l ~/comfyui/ComfyUI/models/unet/ ~/comfyui/ComfyUI/models/clip/ ~/comfyui/ComfyUI/models/vae/ > ~/golden_cfg/models_inventory.txt 2>&1
~/comfyui/venv/bin/pip freeze > ~/golden_cfg/pip_freeze.txt 2>/dev/null
pkg list-installed > ~/golden_cfg/pkg_list.txt 2>/dev/null

# ---- 6. 黄金四件在位验收 ----
echo "===== 黄金四件在位检查 ====="
for f in \
  ~/comfyui/ComfyUI/models/unet/sd15_Q4_0.gguf \
  ~/comfyui/ComfyUI/models/unet/sd15_dequant_fp16.safetensors \
  ~/comfyui/ComfyUI/models/clip/sd15_clip_l.safetensors \
  ~/comfyui/ComfyUI/models/vae/vae-ft-mse-840000-ema-pruned.safetensors ; do
  [ -f "$f" ] && echo "OK    $f" || echo "缺失! $f"
done

echo "===== 第一套备份 ~/golden_cfg ====="
ls -l ~/golden_cfg

# ---- 7. 第二套备份(公共存储, 更耐活) ----
termux-setup-storage; sleep 3
if [ -d ~/storage/shared ]; then
  mkdir -p ~/storage/shared/comfyui_golden_backup
  cp ~/golden_cfg/* ~/storage/shared/comfyui_golden_backup/ \
    && echo "第二套已存: 手机文件管理器 -> 内部存储/comfyui_golden_backup"
else
  cp -r ~/golden_cfg ~/golden_cfg_bak
  echo "公共存储不可用, 第二套暂放 ~/golden_cfg_bak"
fi

echo "===== 备份完成 GOLDEN v1 ====="
