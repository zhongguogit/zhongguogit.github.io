#!/data/data/com.termux/files/usr/bin/bash
# 一键复活 v2 —— 清场→等服务→验证上传→守夜人上岗 (2026-11-18)
echo "==第1步: 清场(杀掉所有旧进程)=="
pkill -9 -f "main.py" 2>/dev/null; pkill -9 -f pipi_batch 2>/dev/null; pkill -9 -f watchdog.sh 2>/dev/null
sleep 3
echo "==第2步: 拉起服务(最多等3分钟, 请耐心)=="
nohup ~/golden_cfg/start_golden.sh > ~/golden.log 2>&1 &
ok=0
for i in $(seq 1 36); do
  curl -s --max-time 5 http://127.0.0.1:8188/system_stats >/dev/null && { ok=1; break; }
  sleep 5
done
[ "$ok" = "1" ] && echo "✅ 服务已醒" || { echo "❌ 服务3分钟没醒, 原因如下:"; tail -5 ~/golden.log; exit 1; }
echo "==第3步: 验证上传+守夜人上岗=="
~/comfyui/venv/bin/python - <<'PYEOF'
import urllib.request, urllib.error, glob, os, uuid
f = sorted(glob.glob(os.path.expanduser('~/vidwork/src/f*.jpg')))
if not f:
    print("⚠️ 源帧目录为空, 跳过验证")
else:
    f = f[0]; name = os.path.basename(f)
    b = uuid.uuid4().hex; body = b""
    body += ("--%s\r\n" % b).encode()
    body += ('Content-Disposition: form-data; name="image"; filename="%s"\r\nContent-Type: image/jpeg\r\n\r\n' % name).encode() + open(f,'rb').read() + b"\r\n"
    body += ("--%s\r\n" % b).encode() + b'Content-Disposition: form-data; name="overwrite"\r\n\r\n1\r\n'
    body += ("--%s\r\n" % b).encode() + b'Content-Disposition: form-data; name="type"\r\n\r\ninput\r\n'
    body += ("--%s--\r\n" % b).encode()
    req = urllib.request.Request('http://127.0.0.1:8188/upload/image', data=body, headers={'Content-Type':'multipart/form-data; boundary='+b})
    try:
        r = urllib.request.urlopen(req, timeout=60)
        print("✅ 上传验证成功!")
    except urllib.error.HTTPError as e:
        print("❌ 上传被拒:", e.code, repr(e.read().decode()[:300]))
os.system("nohup ~/vidwork/watchdog.sh > ~/vidwork/watchdog.log 2>&1 &")
print("🐕 守夜人已上岗! 看进度: cat ~/vidwork/done.txt | wc -l")
PYEOF
