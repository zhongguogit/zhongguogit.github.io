#!/data/data/com.termux/files/usr/bin/bash
# 万能守夜人模板 —— 任何服务都能套, 改4个槽位即可 (2026-11-18)
# ============ 4 个槽位 ============
SERVICE_URL="http://127.0.0.1:8188/system_stats"    # 健康检查; 没有网址写 none
START_CMD="$HOME/golden_cfg/start_golden.sh"        # 服务死了怎么拉起
WORK_CMD="$HOME/comfyui/venv/bin/python -u $HOME/vidwork/pipi_batch.py"   # 要干的活
SUCCESS_CMD="[ \$(cat \$HOME/vidwork/done.txt 2>/dev/null | wc -l) -ge 43 ]"   # 什么算干完
# ==================================
termux-wake-lock
cd $HOME
for i in $(seq 1 20); do
  if [ "$SERVICE_URL" != "none" ]; then
    curl -s --max-time 5 "$SERVICE_URL" >/dev/null || {
      echo "[$(date +%H:%M)] 服务死了, 拉起来"
      nohup $START_CMD > ~/keepalive_server.log 2>&1 &
      sleep 70
    }
  fi
  $SUCCESS_CMD && { echo "[$(date +%H:%M)] ✅ 活干完了"; break; }
  echo "[$(date +%H:%M)] 第 $i 轮开工"
  $WORK_CMD >> ~/keepalive_work.log 2>&1
  sleep 5
done
# 操作: 上岗 nohup ~/keepalive.sh > ~/keepalive.log 2>&1 &
#       看状态 tail -5 ~/keepalive.log
#       撤岗 pkill -f keepalive.sh
