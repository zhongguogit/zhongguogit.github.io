#!/data/data/com.termux/files/usr/bin/bash
# 守夜人 v3 —— 每轮换全新服务器 + 账本够43自动拼片 (2026-11-18)
termux-wake-lock
cd ~/vidwork
for i in $(seq 1 30); do
  D=$(cat ~/vidwork/done.txt 2>/dev/null | wc -l)
  [ "$D" -ge 43 ] && break
  echo "[$(date +%H:%M)] 第$i轮: 换全新服务器"
  pkill -9 -f "main.py" 2>/dev/null
  sleep 2
  nohup ~/golden_cfg/start_golden.sh > ~/golden.log 2>&1 &
  up=0
  for w in $(seq 1 36); do
    curl -s --max-time 5 http://127.0.0.1:8188/system_stats >/dev/null && { up=1; break; }
    sleep 5
  done
  [ "$up" = "1" ] || { echo "服务没起来, 等70秒重试"; sleep 70; continue; }
  ~/comfyui/venv/bin/python -u ~/vidwork/pipi_batch.py >> ~/vidwork/pipi_log.txt 2>&1
  sleep 5
done
D=$(cat ~/vidwork/done.txt 2>/dev/null | wc -l)
echo "账本: $D/43"
mkdir -p ~/vidwork/frames && rm -f ~/vidwork/frames/seq_*.png
n=0
for f in $(ls ~/comfyui/ComfyUI/output/pip_*.png 2>/dev/null | sort | head -43); do
  n=$((n+1))
  cp "$f" ~/vidwork/frames/seq_$(printf %03d $n).png
done
ffmpeg -y -framerate 10 -i ~/vidwork/frames/seq_%03d.png -c:v libx264 -pix_fmt yuv420p ~/vidwork/pipi_done.mp4 && echo "✅ 收工: ~/vidwork/pipi_done.mp4"
